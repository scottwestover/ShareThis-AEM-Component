Developer: Scott Westover

I built this component so you can utilize the ShareThis api to share your content on your 
webpages. 

The component will display a default text to input your developer id, and will stay
that way until you fill out the dialog box. Once this is filled out the component
will refresh and display the share this buttons that are specified in the share
this code, inside the jsp file.

You can add more Share This buttons by adding in the correct code in the jsp file.